#!/usr/bin/python3
#
# Copyright (C) 2022 The Android Open Source Project
#
# SPDX-License-Identifier: Apache-2.0
#

from twrpdtgen.main import main

if __name__ == '__main__':
	main()
